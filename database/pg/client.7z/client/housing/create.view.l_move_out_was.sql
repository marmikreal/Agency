CREATE VIEW l_move_out_was AS
SELECT exit_status_code AS move_out_was_code,description
FROM l_exit_status;
