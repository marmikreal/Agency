CREATE VIEW l_hospital AS SELECT DISTINCT facility AS hospital_code, facility AS description FROM hospital;

