CREATE OR REPLACE VIEW staff_rc AS
SELECT * FROM staff WHERE staff_position_code = 'RC';