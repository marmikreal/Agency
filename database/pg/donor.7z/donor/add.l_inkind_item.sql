INSERT INTO tbl_l_inkind_item VALUES ('BOOK','Books',sys_user(),current_timestamp,sys_user(),current_timestamp);
INSERT INTO tbl_l_inkind_item VALUES ('CLOTHING','Clothing',sys_user(),current_timestamp,sys_user(),current_timestamp);
INSERT INTO tbl_l_inkind_item VALUES ('COATS','Coats',sys_user(),current_timestamp,sys_user(),current_timestamp);
INSERT INTO tbl_l_inkind_item VALUES ('COFFEE','Coffee',sys_user(),current_timestamp,sys_user(),current_timestamp);
INSERT INTO tbl_l_inkind_item VALUES ('COMPUTER','Computers',sys_user(),current_timestamp,sys_user(),current_timestamp);
INSERT INTO tbl_l_inkind_item VALUES ('FOOD','Foodstuffs',sys_user(),current_timestamp,sys_user(),current_timestamp);
INSERT INTO tbl_l_inkind_item VALUES ('FURN','Furniture',sys_user(),current_timestamp,sys_user(),current_timestamp);
INSERT INTO tbl_l_inkind_item VALUES ('HOUSE','Household goods',sys_user(),current_timestamp,sys_user(),current_timestamp);
INSERT INTO tbl_l_inkind_item VALUES ('HYG','Hygiene kits',sys_user(),current_timestamp,sys_user(),current_timestamp);
INSERT INTO tbl_l_inkind_item VALUES ('MISC','Miscellaneous Stuff',sys_user(),current_timestamp,sys_user(),current_timestamp);
INSERT INTO tbl_l_inkind_item VALUES ('Other','Other -- describe below',sys_user(),current_timestamp,sys_user(),current_timestamp);
INSERT INTO tbl_l_inkind_item VALUES ('RAZOR','Razors',sys_user(),current_timestamp,sys_user(),current_timestamp);
INSERT INTO tbl_l_inkind_item VALUES ('SHAMP','Shampoo',sys_user(),current_timestamp,sys_user(),current_timestamp);
INSERT INTO tbl_l_inkind_item VALUES ('SHOES','Shoes',sys_user(),current_timestamp,sys_user(),current_timestamp);
INSERT INTO tbl_l_inkind_item VALUES ('SOAP','Soap',sys_user(),current_timestamp,sys_user(),current_timestamp);
INSERT INTO tbl_l_inkind_item VALUES ('TOOTHBRU','Toothbrushes',sys_user(),current_timestamp,sys_user(),current_timestamp);
INSERT INTO tbl_l_inkind_item VALUES ('TICKET','Tickets',sys_user(),current_timestamp,sys_user(),current_timestamp);
INSERT INTO tbl_l_inkind_item VALUES ('TOWEL','Towels',sys_user(),current_timestamp,sys_user(),current_timestamp);

