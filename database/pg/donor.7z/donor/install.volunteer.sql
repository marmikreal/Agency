/*
 * Lookups and Tables needed for
 * tracking volunteer hours and
 * registrations.
 */

\i create.l_volunteer_location.sql
\i create.l_length_commitment.sql
\i create.l_referral_source.sql
\i create.l_volunteer_activity.sql

\i create.tbl_volunteer_reg.sql
\i create.tbl_volunteer_hours.sql

