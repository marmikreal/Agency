INSERT INTO tbl_l_active VALUES ('?','Active status unknown',sys_user(),current_timestamp,sys_user(),current_timestamp);
INSERT INTO tbl_l_active VALUES ('N','No, not currently Active',sys_user(),current_timestamp,sys_user(),current_timestamp);
INSERT INTO tbl_l_active VALUES ('X','No longer exists (Dead,bankrupt,etc.)',sys_user(),current_timestamp,sys_user(),current_timestamp);
INSERT INTO tbl_l_active VALUES ('Y','Yes, currently Active',sys_user(),current_timestamp,sys_user(),current_timestamp);

