INSERT INTO tbl_l_address_type (address_type_code,description,added_by,added_at,changed_by,changed_at) VALUES ('HOME','Home Address',sys_user(),current_timestamp,sys_user(),current_timestamp);
INSERT INTO tbl_l_address_type (address_type_code,description,added_by,added_at,changed_by,changed_at) VALUES ('BUSINESS','Business Address',sys_user(),current_timestamp,sys_user(),current_timestamp);
INSERT INTO tbl_l_address_type (address_type_code,description,added_by,added_at,changed_by,changed_at) VALUES ('OTHER','Other Address',sys_user(),current_timestamp,sys_user(),current_timestamp);
INSERT INTO tbl_l_address_type (address_type_code,description,added_by,added_at,changed_by,changed_at) VALUES ('UNKNOWN','Unknown or Unspecified',sys_user(),current_timestamp,sys_user(),current_timestamp);
