/*
 * Proposals
 * Lookups and table
 *
 */

\i create.l_proposal_status.sql
\i add.l_proposal_status.sql
\i create.l_proposal_current_status.sql
\i create.l_proposal_next_action.sql
\i create.tbl_proposal.sql
