/*
DROP VIEW info_additional;
DROP table tbl_info_additional;
DROP VIEW l_info_additional_type;
DROP table tbl_l_info_additional_type;
DROP VIEW l_value_type;
DROP table tbl_l_value_type;
*/

\i create.l_value_type.sql
\i create.l_info_additional_type.sql
\i create.tbl_info_additional.sql

